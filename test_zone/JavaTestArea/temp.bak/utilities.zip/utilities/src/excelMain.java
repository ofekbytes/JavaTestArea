import compares.*;

public class excelMain 
{

	public static void main(String[] args) 
	{
		Excel ex = new Excel();
	}
	

}
	